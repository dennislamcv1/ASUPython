# Python Game
import PySimpleGUI as sg
from characters import Hero, Mage, Warrior, Wizard

# GUI Stuff
layout = [[
    sg.Text("Character 1 Type:", size=(15, 1)),
    sg.Combo(["Hero", "Mage", "Warrior", "Wizard"], key="char1")
], [
    sg.Text("Character 1 Name:", size=(15, 1)),
    sg.InputText(key="char1_name")
], [
    sg.Text("Character 2 Type:", size=(15, 1)),
    sg.Combo(["Hero", "Mage", "Warrior", "Wizard"], key="char2")
], [
    sg.Text("Character 2 Name:", size=(15, 1)),
    sg.InputText(key="char2_name")
],[
    sg.Button("Battle!", key="start")
], [
    sg.Multiline(key="history", disabled=True, size=(500, None))
]]
window = sg.Window("Character Battle", layout, size=(500,300))

def declare_winner(winner):
    sg.Popup("We have a winner!", winner.to_string())

def fight(char1, char2):
    # Print which characters are fighting
    window["history"].print("Characters in Fight:")
    window["history"].print(char1.to_string())
    window["history"].print(char2.to_string())

    # Start the fight
    window["history"].print("Fight Started\n")

    rounds = 0
    while char1.isAlive() and char2.isAlive():
        rounds += 1

        # Deal damage to the characters
        if char1.isAlive():
            char2.hit(char1.attack())

        if char2.isAlive():
            char1.hit(char2.attack())

        # Print post-round status
        window["history"].print(f"Status After Round {rounds}:")
        window["history"].print(char1.to_string())
        window["history"].print(char2.to_string())
        window["history"].print("\n")

        # Determine the winner
        is_winner_1 = char1.isAlive() and not char2.isAlive()
        is_winner_2 = char2.isAlive() and not char1.isAlive()

        # Determine if the battle has ended, and print the winner
        if is_winner_1 or is_winner_2:
            winner = char1 if is_winner_1 else char2
            window["history"].print("The battle has ended! Winner:")
            window["history"].print(winner.to_string())
            window["history"].print("\n")
            declare_winner(winner)
        
        window.read(timeout=1000) # wait 1 second before next round

def main():
    while True:
        event, values = window.read()
        if event is None or event == "Exit": break

        if event == "start":
            char1_type = values["char1"]
            char1_name = values["char1_name"]
            char2_type = values["char2"]
            char2_name = values["char2_name"]
            if char1_type == "" or char1_name == "" or char2_type == "" or char2_name == "":
                sg.Popup("You must specify all character info!")
                continue
            
            types = [Hero, Mage, Warrior, Wizard]
            char1 = [char_type(char1_name) for char_type in types if char_type.__name__ == char1_type][0]
            char2 = [char_type(char2_name) for char_type in types if char_type.__name__ == char2_type][0]
            
            # Start Fight
            fight(char1, char2)

if __name__ == "__main__":
    main()