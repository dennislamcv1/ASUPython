# Python Game
import random
from characters import Hero, Mage, Warrior, Wizard

# Possible character names
names = ["CJ", "Merlin", "Bob", "Jerry", "Alice"]
types = [Hero, Mage, Warrior, Wizard]

# Generate two random characters
char_1 = random.choice(types)(random.choice(names))
char_2 = random.choice(types)(random.choice(names))

# Print which characters are fighting
print("Characters in Fight:")
char_1.print()
char_2.print()

# Start the fight
print("Fight Started\n")

rounds = 0
while char_1.isAlive() and char_2.isAlive():
    rounds += 1

    # Deal damage to the characters
    if char_1.isAlive():
        char_2.hit(char_1.attack())

    if char_2.isAlive():
        char_1.hit(char_2.attack())

    # Print post-round status
    print(f"Status After Round {rounds}:")
    char_1.print()
    char_2.print()
    print("\n")

    # Determine the winner
    is_winner_1 = char_1.isAlive() and not char_2.isAlive()
    is_winner_2 = char_2.isAlive() and not char_1.isAlive()

    # Determine if the battle has ended, and print the winner
    if is_winner_1 or is_winner_2:
        winner = char_1 if is_winner_1 else char_2
        print("The battle has ended! Winner:")
        winner.print()
        print("\n")