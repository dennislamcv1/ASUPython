class Character:
    def __init__(self, name, strength, health):
        self.__name = name
        self.__strength = strength
        self.__health = health
    
    def attack(self):
        return self.__strength

    def hit(self, points):
        self.__health -= points
    
    def isAlive(self):
        return self.__health > 0

    def print(self):
        print(f"[ Class: {self.__class__.__name__}, Name: {self.__name}, Strength: {self.__strength}, Health: {self.__health} ]")

class Hero(Character):
    def __init__(self, name):
        super().__init__(name, 16, 100)

class Mage(Character):
    def __init__(self, name):
        super().__init__(name, 8, 150)

class Warrior(Character):
    def __init__(self, name):
        super().__init__(name, 18, 120)

class Wizard(Character):
    def __init__(self, name):
        super().__init__(name, 22, 80)